package com.example.pesquisaapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

public class adminActivity extends AppCompatActivity {

    private TextView txtNome, txtCelular, txtCidade, txtRenda, txtData, txtHora, txtVotoPrefeito, txtProblemasCidade, txtCandidatoEscolhido, txtResumo;
    private Button btnVoltarLogin;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        txtResumo = findViewById(R.id.txtResumo);
        btnVoltarLogin = findViewById(R.id.btnVoltarLogin);
        btnVoltarLogin.setOnClickListener(v -> btnVoltarLogin());

        JSONArray dadosArray = lerArquivoJson();

        if (dadosArray != null) {
            StringBuilder resumoFinal = new StringBuilder();

            try {
                for (int i = 0; i < dadosArray.length(); i++) {
                    JSONObject dados = dadosArray.getJSONObject(i);
                    JSONObject cadastro = dados.getJSONObject("cadastroPesquisa");
                    JSONObject espontanea = dados.getJSONObject("pesquisaEspontanea");
                    JSONObject estimulada = dados.getJSONObject("pesquisaEstimulada");

                    resumoFinal.append("Pesquisa ").append(i + 1).append(":\n")
                            .append("Nome: ").append(cadastro.getString("nome")).append("\n")
                            .append("Celular: ").append(cadastro.getString("celular")).append("\n")
                            .append("Cidade: ").append(cadastro.getString("cidade")).append("\n")
                            .append("Renda: ").append(cadastro.getString("renda")).append("\n")
                            .append("Data: ").append(cadastro.getString("data")).append("\n")
                            .append("Hora: ").append(cadastro.getString("hora")).append("\n")
                            .append("Voto Espontâneo: ").append(espontanea.getString("votoPrefeito")).append("\n")
                            .append("Problemas da cidade: ").append(espontanea.getString("problemasCidade")).append("\n")
                            .append("Candidato Estimulado: ").append(estimulada.getString("candidatoEscolhido")).append("\n")
                            .append("-------------------------------\n\n");
                }

                txtResumo.setText(resumoFinal.toString());

            } catch (Exception e) {
                txtResumo.setText("Erro ao ler dados: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            txtResumo.setText("Nenhum dado encontrado.");
        }
    }


    private void btnVoltarLogin() {
        Intent intent = new Intent(adminActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private JSONArray lerArquivoJson() {
        try {
            FileInputStream fis = openFileInput("pesquisa.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder sb = new StringBuilder();
            String linha;

            while ((linha = reader.readLine()) != null) {
                sb.append(linha);
            }

            reader.close();
            fis.close();

            return new JSONArray(sb.toString());

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
