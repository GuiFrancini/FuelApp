
package com.example.pesquisaapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PesquisaEstimulada extends AppCompatActivity {

    private RadioGroup radioGroupCandidatos;
    private Button btnProsseguir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesquisa_estimulada); // Confere o nome do XML

        radioGroupCandidatos = findViewById(R.id.radioGroupCandidatos);
        btnProsseguir = findViewById(R.id.btnProsseguirEstimulada);

        btnProsseguir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int selectedId = radioGroupCandidatos.getCheckedRadioButtonId();

                if (selectedId == -1) {
                    Toast.makeText(PesquisaEstimulada.this, "Por favor, selecione um candidato.", Toast.LENGTH_SHORT).show();
                    return;
                }

                RadioButton selectedRadioButton = findViewById(selectedId);
                String candidatoEscolhido = selectedRadioButton.getText().toString();

                Intent intentAnterior = getIntent();
                String votoPrefeito = intentAnterior.getStringExtra("votoPrefeitoEspontaneo");
                String problemasCidade = intentAnterior.getStringExtra("problemasCidade");


                // Passar para próxima tela
                Intent intent = new Intent(PesquisaEstimulada.this, CadastroPesquisa.class);
                intent.putExtra("votoPrefeitoEspontaneo", votoPrefeito);
                intent.putExtra("problemasCidade", problemasCidade);
                intent.putExtra("candidatoEscolhido", candidatoEscolhido);
                startActivity(intent);
            }
        });
    }
}
