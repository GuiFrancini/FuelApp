package com.example.pesquisaapp;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;


import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;


public class Grafico extends AppCompatActivity {

    private BarChart barChartCandidatos, barChartProblemas, barChartEspontaneo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grafico);

        barChartCandidatos = findViewById(R.id.barChartCandidatos);
        barChartProblemas = findViewById(R.id.barChartProblemas);
        barChartEspontaneo = findViewById(R.id.barChartEspontaneo);

        JSONArray dadosArray = lerArquivoJson();
        if (dadosArray != null) {
            gerarGrafico(dadosArray, "candidatoEscolhido", "Votos por Candidato", barChartCandidatos, "pesquisaEstimulada");
            gerarGrafico(dadosArray, "problemasCidade", "Problemas da Cidade", barChartProblemas, "pesquisaEspontanea");
            gerarGrafico(dadosArray, "votoPrefeito", "Voto Espontâneo", barChartEspontaneo, "pesquisaEspontanea");
        }
    }

    private void gerarGrafico(JSONArray dadosArray, String chave, String titulo, BarChart chart, String secaoJson) {
        HashMap<String, Integer> contagem = new HashMap<>();

        try {
            for (int i = 0; i < dadosArray.length(); i++) {
                JSONObject dados = dadosArray.getJSONObject(i);
                JSONObject secao = dados.getJSONObject(secaoJson);
                String valor = secao.getString(chave);

                contagem.put(valor, contagem.getOrDefault(valor, 0) + 1);
            }

            ArrayList<BarEntry> entries = new ArrayList<>();
            ArrayList<String> labels = new ArrayList<>();
            int index = 0;

            for (String item : contagem.keySet()) {
                entries.add(new BarEntry(index, contagem.get(item)));
                labels.add(item);
                index++;
            }

            BarDataSet dataSet = new BarDataSet(entries, titulo);
            BarData barData = new BarData(dataSet);

            chart.setData(barData);
            XAxis xAxis = chart.getXAxis();
            xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setGranularity(1f);
            xAxis.setLabelRotationAngle(-45);
            chart.getDescription().setText(titulo);
            chart.animateY(1000);
            chart.invalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private JSONArray lerArquivoJson() {
        try {
            FileInputStream fis = openFileInput("pesquisa.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder sb = new StringBuilder();
            String linha;
            while ((linha = reader.readLine()) != null) {
                sb.append(linha);
            }
            reader.close();
            fis.close();
            return new JSONArray(sb.toString());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}

