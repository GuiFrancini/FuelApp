package com.example.pesquisaapp;

import android.os.Bundle;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import android.widget.Toast;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.OutputStreamWriter;          // Para escrever texto no arquivi
//18 importaçoes



import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class CadastroPesquisa extends AppCompatActivity {

    private EditText edtNome, edtCelular, edtData, edtHora, edtCidade;
    private Spinner spinnerRenda;
    private Button  btnVoltarLogin, btnFinalizarPesquisa, btnCadastrarPesquisa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_pesquisa);

        edtNome = findViewById(R.id.edtNome);
        edtCelular = findViewById(R.id.edtCelular);
        edtData = findViewById(R.id.edtData);
        edtHora = findViewById(R.id.edtHora);
        edtCidade = findViewById(R.id.edtCidade);
        spinnerRenda = findViewById(R.id.spinnerRenda);
        btnVoltarLogin = findViewById(R.id.btnVoltarLogin);
        btnCadastrarPesquisa = findViewById(R.id.btnCadastrarPesquisa);



        // Obter data e hora atuais do sistema
        SimpleDateFormat sdfData = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdfHora = new SimpleDateFormat("HH:mm");

        String dataAtual = sdfData.format(new Date());
        String horaAtual = sdfHora.format(new Date());

        // Definir no campo de data e hora
        edtData.setText(dataAtual);
        edtHora.setText(horaAtual);

        // Recuperando os dados das pesquisas anteriores
        Intent intent = getIntent();
        String votoPrefeitoEspontaneo = intent.getStringExtra("VotoPrefeitoEspontaneo");
        String problemasCidade1 = intent.getStringExtra("ProblemasCidade");
        String votoPrefeitoEstimulado = intent.getStringExtra("VotoPrefeitoEstimulado");

        // Configurando o Spinner de Faixa Salarial
        String[] faixasRenda = {"Até R$1.000", "R$1.000 - R$3.000", "R$3.000 - R$5.000", "Acima de R$5.000"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, faixasRenda);
        spinnerRenda.setAdapter(adapter);

        // Selecionar a data
        edtData.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int ano = calendar.get(Calendar.YEAR);
            int mes = calendar.get(Calendar.MONTH);
            int dia = calendar.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(CadastroPesquisa.this, (view, year, month, dayOfMonth) ->
                    edtData.setText(dayOfMonth + "/" + (month + 1) + "/" + year), ano, mes, dia);
            datePickerDialog.show();
        });

        // Selecionar a hora
        edtHora.setOnClickListener(v -> {
            Calendar calendar = Calendar.getInstance();
            int hora = calendar.get(Calendar.HOUR_OF_DAY);
            int minuto = calendar.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(CadastroPesquisa.this, (view, hourOfDay, minute) ->
                    edtHora.setText(hourOfDay + ":" + String.format("%02d", minute)), hora, minuto, true);
            timePickerDialog.show();
        });



        // Botão de voltar ao login
        btnVoltarLogin.setOnClickListener(v -> {
            Intent intentVoltarLogin = new Intent(CadastroPesquisa.this, MainActivity.class);
            startActivity(intentVoltarLogin);
            finish();
        });

        btnCadastrarPesquisa.setOnClickListener(v -> {
            // Coletar os dados dos campos

            Intent intent1 = getIntent();
            String votoPrefeito1 = intent.getStringExtra("votoPrefeitoEspontaneo");
            String problemasCidade2 = intent.getStringExtra("problemasCidade");
            String candidatoEscolhido1 = intent.getStringExtra("candidatoEscolhido");

            String nome = edtNome.getText().toString();
            String celular = edtCelular.getText().toString();
            String cidade = edtCidade.getText().toString();
            String renda = spinnerRenda.getSelectedItem().toString();
            String data = edtData.getText().toString();
            String hora = edtHora.getText().toString();

            salvarJsonEmArquivo(nome, celular, cidade, renda, data, hora,
                    votoPrefeito1, problemasCidade2, candidatoEscolhido1);

            // Exibir uma mensagem de sucesso (Toast)
            Toast.makeText(CadastroPesquisa.this, "Pesquisa Cadastrada com Sucesso!", Toast.LENGTH_SHORT).show();
        });


    }

    private void salvarJsonEmArquivo(String nome, String celular, String cidade, String renda,
                                     String data, String hora, String votoPrefeito, String problemasCidade,
                                     String candidatoEscolhido) {
        try {
            // Criar novo objeto de pesquisa
            JSONObject pesquisa = new JSONObject();

            JSONObject cadastro = new JSONObject();
            cadastro.put("nome", nome);
            cadastro.put("celular", celular);
            cadastro.put("cidade", cidade);
            cadastro.put("renda", renda);
            cadastro.put("data", data);
            cadastro.put("hora", hora);

            JSONObject espontanea = new JSONObject();
            espontanea.put("votoPrefeito", votoPrefeito);
            espontanea.put("problemasCidade", problemasCidade);

            JSONObject estimulada = new JSONObject();
            estimulada.put("candidatoEscolhido", candidatoEscolhido);

            pesquisa.put("cadastroPesquisa", cadastro);
            pesquisa.put("pesquisaEspontanea", espontanea);
            pesquisa.put("pesquisaEstimulada", estimulada);

            // le ad pesquisas antigas se existirem
            JSONArray todasPesquisas;

            try {
                FileInputStream fis = openFileInput("pesquisa.json");
                BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
                StringBuilder sb = new StringBuilder();
                String linha;
                while ((linha = reader.readLine()) != null) {
                    sb.append(linha);
                }
                reader.close();
                fis.close();

                todasPesquisas = new JSONArray(sb.toString());
            } catch (Exception e) {
                // Se o arquivo não existe ou está vazio, criamos um novo JSONArray
                todasPesquisas = new JSONArray();
            }

            // Adiciona a nova pesquisa ao array
            todasPesquisas.put(pesquisa);

            // Salva tudo de volta
            FileOutputStream fos = openFileOutput("pesquisa.json", MODE_PRIVATE);
            OutputStreamWriter writer = new OutputStreamWriter(fos);
            writer.write(todasPesquisas.toString(4)); // Indentado
            writer.close();
            fos.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }





}
