package com.example.pesquisaapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
//sem importar todas as libs os metodos nao funcionam


public class pesquisaActivity extends AppCompatActivity {

    private Button btnEspontanea, btnEstimulada;//declarando as variaveis do tipo button

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesquisa);

        btnEspontanea = findViewById(R.id.btnPesquisaEspontanea);
        btnEstimulada = findViewById(R.id.btnPesquisaEstimulada);

        btnEspontanea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pesquisaActivity.this, PesquisaEspontanea.class);
                startActivity(intent);
            }
        });

        btnEstimulada.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(pesquisaActivity.this, PesquisaEstimulada.class);
                startActivity(intent);
            }
        });
    }}

