package com.example.pesquisaapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.File;
import java.io.FileOutputStream;

public class adminActivity extends AppCompatActivity {

    private TextView txtResumo;
    private Button btnVoltarLogin, btnVerGraficos, btnGerarPDF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        txtResumo = findViewById(R.id.txtResumo);
        btnVoltarLogin = findViewById(R.id.btnVoltarLogin);
        btnVerGraficos = findViewById(R.id.btnVerGraficos);
        btnGerarPDF = findViewById(R.id.btnGerarPDF);

        btnVoltarLogin.setOnClickListener(v -> btnVoltarLogin());
        btnVerGraficos.setOnClickListener(v -> btnVerGraficos());
        btnGerarPDF.setOnClickListener(v -> gerarPDF(txtResumo.getText().toString()));

        JSONArray dadosArray = lerArquivoJson();

        if (dadosArray != null) {
            StringBuilder resumoFinal = new StringBuilder();

            try {
                for (int i = 0; i < dadosArray.length(); i++) {
                    JSONObject dados = dadosArray.getJSONObject(i);
                    JSONObject cadastro = dados.getJSONObject("cadastroPesquisa");
                    JSONObject espontanea = dados.getJSONObject("pesquisaEspontanea");
                    JSONObject estimulada = dados.getJSONObject("pesquisaEstimulada");

                    resumoFinal.append("Pesquisa ").append(i + 1).append(":\n")
                            .append("Nome: ").append(cadastro.getString("nome")).append("\n")
                            .append("Celular: ").append(cadastro.getString("celular")).append("\n")
                            .append("Cidade: ").append(cadastro.getString("cidade")).append("\n")
                            .append("Renda: ").append(cadastro.getString("renda")).append("\n")
                            .append("Data: ").append(cadastro.getString("data")).append("\n")
                            .append("Hora: ").append(cadastro.getString("hora")).append("\n")
                            .append("Voto Espontâneo: ").append(espontanea.getString("votoPrefeito")).append("\n")
                            .append("Problemas da cidade: ").append(espontanea.getString("problemasCidade")).append("\n")
                            .append("Candidato Estimulado: ").append(estimulada.getString("candidatoEscolhido")).append("\n")
                            .append("-------------------------------\n\n");
                }

                txtResumo.setText(resumoFinal.toString());

            } catch (Exception e) {
                txtResumo.setText("Erro ao ler dados: " + e.getMessage());
                e.printStackTrace();
            }
        } else {
            txtResumo.setText("Nenhum dado encontrado.");
        }
    }

    private void btnVoltarLogin() {
        Intent intent = new Intent(adminActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void btnVerGraficos() {
        Intent intent = new Intent(adminActivity.this, Grafico.class);
        startActivity(intent);
    }

    private JSONArray lerArquivoJson() {
        try {
            FileInputStream fis = openFileInput("pesquisa.json");
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            StringBuilder sb = new StringBuilder();
            String linha;

            while ((linha = reader.readLine()) != null) {
                sb.append(linha);
            }

            reader.close();
            fis.close();

            return new JSONArray(sb.toString());

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void abrirPDF(File file) {
        Uri pdfUri = Uri.fromFile(file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(pdfUri, "application/pdf");
        intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);

        // Verifica se algum aplicativo pode abrir o PDF
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "Nenhum aplicativo pode abrir este PDF", Toast.LENGTH_SHORT).show();
        }
    }

    private void compartilharPDF(File file) {
        Uri pdfUri = Uri.fromFile(file);
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("application/pdf");
        shareIntent.putExtra(Intent.EXTRA_STREAM, pdfUri);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Relatório de Pesquisa");
        shareIntent.putExtra(Intent.EXTRA_TEXT, "Aqui está o PDF com os resultados da pesquisa!");

        // Verifica se há aplicativos que podem compartilhar o PDF
        if (shareIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(Intent.createChooser(shareIntent, "Compartilhar via"));
        } else {
            Toast.makeText(this, "Nenhum aplicativo para compartilhar", Toast.LENGTH_SHORT).show();
        }
    }

    private void gerarPDF(String conteudo) {
        PdfDocument documento = new PdfDocument();
        Paint paint = new Paint();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create(); // A4
        PdfDocument.Page pagina = documento.startPage(pageInfo);

        Canvas canvas = pagina.getCanvas();
        int x = 40, y = 50;

        for (String linha : conteudo.split("\n")) {
            canvas.drawText(linha, x, y, paint);
            y += 20;
        }

        documento.finishPage(pagina);

        try {
            File pdfDir = new File(getExternalFilesDir(null), "pdfs");
            if (!pdfDir.exists()) {
                pdfDir.mkdir();
            }

            File file = new File(pdfDir, "relatorio_pesquisa.pdf");
            FileOutputStream fos = new FileOutputStream(file);
            documento.writeTo(fos);
            documento.close();
            fos.close();

            // Abrir o PDF após gerar
            abrirPDF(file);

            // Compartilhar o PDF
            compartilharPDF(file);

            Toast.makeText(this, "PDF gerado em: " + file.getAbsolutePath(), Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Erro ao gerar PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

}
